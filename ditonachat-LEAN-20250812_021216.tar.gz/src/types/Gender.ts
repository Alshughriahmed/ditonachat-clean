export enum Gender {
  MALE = "MALE",
  FEMALE = "FEMALE",
  ANY = "ANY", // استخدم ANY بدلاً من ALL
}
