export default function Cancel() {
  return (
    <div style={{ maxWidth: 520, margin: '40px auto', fontFamily: 'system-ui' }}>
      <h1>تم إلغاء العملية ❌</h1>
      <p>لم يتم تفعيل الاشتراك. يمكنك المحاولة مرة أخرى في أي وقت.</p>
    </div>
  );
}
