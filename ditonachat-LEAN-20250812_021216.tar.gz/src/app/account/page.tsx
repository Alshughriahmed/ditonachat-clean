'use client';

import { useEffect, useState } from 'react';
import { useSubscriptionAccess } from '@/hooks/useSubscriptionAccess';

export default function AccountPage() {
  const { active } = useSubscriptionAccess();
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');

  async function openPortal() {
    setLoading(true); setMsg('');
    try {
      const res = await fetch('/api/billing/portal', { method: 'POST' });
      const data = await res.json();
      if (data?.url) window.location.href = data.url;
      else setMsg(data?.error || 'تعذر فتح بوابة الفوترة.');
    } catch (e:any) {
      setMsg(e?.message || 'خطأ غير متوقع.');
    } finally {
      setLoading(false);
    }
  }

  async function deactivateMock() {
    setLoading(true);
    await fetch('/api/subscription/deactivate', { method: 'POST' });
    window.location.reload();
  }

  return (
    <div className="mx-auto max-w-lg p-6">
      <h1 className="mb-4 text-2xl font-bold">حسابي</h1>
      <div className="mb-4 rounded-xl border p-4">
        <div className="font-semibold">حالة الاشتراك: {active ? 'مفعل ✅' : 'غير مفعل ❌'}</div>
        <div className="text-sm text-gray-500">يمكنك إدارة الاشتراك من خلال بوابة Stripe.</div>
      </div>

      <div className="flex items-center gap-3">
        <button onClick={openPortal} disabled={loading} className="rounded-xl bg-black px-4 py-2 text-white">
          إدارة الاشتراك
        </button>
        {!active && (
          <form method="post" action="/api/subscription/activate">
            <button className="rounded-xl border px-4 py-2">تفعيل وهمي</button>
          </form>
        )}
        {active && (
          <button onClick={deactivateMock} disabled={loading} className="rounded-xl border px-4 py-2">
            إلغاء (وهمي)
          </button>
        )}
      </div>

      {msg && <div className="mt-4 rounded bg-red-50 p-3 text-sm text-red-700">{msg}</div>}
    </div>
  );
}
