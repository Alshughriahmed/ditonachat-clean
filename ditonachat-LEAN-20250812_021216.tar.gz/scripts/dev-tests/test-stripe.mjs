const key = process.env.STRIPE_SECRET_KEY;
if (!key) {
  console.log("SKIP Stripe: STRIPE_SECRET_KEY غير متوفر");
  process.exit(0);
}
const res = await fetch("https://api.stripe.com/v1/products?limit=1", {
  headers: { Authorization: `Bearer ${key}` }
});
if (!res.ok) { console.error("Stripe API failed", res.status); process.exit(1); }
const js = await res.json();
console.log("OK Stripe: products_count =", Array.isArray(js.data) ? js.data.length : "unknown");
