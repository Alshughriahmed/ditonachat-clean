const url = process.env.UPSTASH_REDIS_REST_URL;
const token = process.env.UPSTASH_REDIS_REST_TOKEN;

if (!url || !token) {
  console.log("SKIP Redis: UPSTASH_REDIS_REST_URL/UPSTASH_REDIS_REST_TOKEN غير متوفرة");
  process.exit(0);
}

const key = "ditona:test";
const value = String(Date.now());

const headers = { Authorization: `Bearer ${token}` };

const setUrl = `${url}/set/${encodeURIComponent(key)}/${encodeURIComponent(value)}`;
const getUrl = `${url}/get/${encodeURIComponent(key)}`;

const res1 = await fetch(setUrl, { headers });
if (!res1.ok) { console.error("Redis SET failed", res1.status); process.exit(1); }

const res2 = await fetch(getUrl, { headers });
if (!res2.ok) { console.error("Redis GET failed", res2.status); process.exit(1); }
const data = await res2.json();
if (!data || data.result !== value) { console.error("Redis value mismatch", data); process.exit(1); }

console.log("OK Redis:", { key, value });
